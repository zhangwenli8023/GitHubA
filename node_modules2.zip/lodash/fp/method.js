var convert = require('./convert'),
    func = convert('method', require('../method'));

func.placeholder = require('./placeholder');
module.exports = func;

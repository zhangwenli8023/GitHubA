var convert = require('./convert'),
    func = convert('invokeArgsMap', require('../invokeMap'));

func.placeholder = require('./placeholder');
module.exports = func;

var convert = require('./convert'),
    func = convert('pad', require('../pad'));

func.placeholder = require('./placeholder');
module.exports = func;
